-- Create users table (extends Supabase auth)
CREATE TABLE users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user', -- 'admin' or 'user'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create members table
CREATE TABLE members (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT NOT NULL,
  membership_type TEXT NOT NULL, -- '6_months', '1_year', '2_years'
  membership_start_date DATE NOT NULL,
  membership_end_date DATE NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create books table
CREATE TABLE books (
  id SERIAL PRIMARY KEY,
  isbn TEXT UNIQUE NOT NULL,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  category TEXT NOT NULL,
  type TEXT NOT NULL, -- 'book' or 'movie'
  total_copies INTEGER NOT NULL,
  available_copies INTEGER NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create book_serials table for tracking individual copies
CREATE TABLE book_serials (
  id SERIAL PRIMARY KEY,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  serial_number TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'available', -- 'available', 'issued', 'damaged'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create transactions table
CREATE TABLE transactions (
  id SERIAL PRIMARY KEY,
  member_id INTEGER NOT NULL REFERENCES members(id),
  book_id INTEGER NOT NULL REFERENCES books(id),
  serial_number TEXT NOT NULL REFERENCES book_serials(serial_number),
  issue_date DATE NOT NULL,
  return_date DATE NOT NULL,
  actual_return_date DATE,
  fine_amount DECIMAL(10, 2) DEFAULT 0,
  fine_paid BOOLEAN DEFAULT FALSE,
  remarks TEXT,
  status TEXT NOT NULL DEFAULT 'issued', -- 'issued', 'returned', 'overdue'
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
ALTER TABLE book_serials ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;

-- RLS Policies for users table
CREATE POLICY "Users can view their own profile" ON users
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Admin can view all users" ON users
  FOR SELECT USING (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

-- RLS Policies for members table
CREATE POLICY "Anyone can view members" ON members
  FOR SELECT USING (TRUE);

CREATE POLICY "Admin can insert members" ON members
  FOR INSERT WITH CHECK (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

CREATE POLICY "Admin can update members" ON members
  FOR UPDATE USING (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

-- RLS Policies for books table
CREATE POLICY "Anyone can view books" ON books
  FOR SELECT USING (TRUE);

CREATE POLICY "Admin can insert books" ON books
  FOR INSERT WITH CHECK (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

CREATE POLICY "Admin can update books" ON books
  FOR UPDATE USING (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

-- RLS Policies for book_serials table
CREATE POLICY "Anyone can view book serials" ON book_serials
  FOR SELECT USING (TRUE);

CREATE POLICY "Admin can manage book serials" ON book_serials
  FOR ALL USING (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

-- RLS Policies for transactions table
CREATE POLICY "Members can view own transactions" ON transactions
  FOR SELECT USING (
    member_id IN (SELECT id FROM members WHERE email = (SELECT email FROM users WHERE id = auth.uid()))
  );

CREATE POLICY "Admin can view all transactions" ON transactions
  FOR SELECT USING (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );

CREATE POLICY "Anyone can insert transactions" ON transactions
  FOR INSERT WITH CHECK (TRUE);

CREATE POLICY "Admin can update transactions" ON transactions
  FOR UPDATE USING (
    (SELECT role FROM users WHERE id = auth.uid()) = 'admin'
  );
