// Authentication Logic

let currentUser
let userRole
let supabase // Declare the supabase variable
let loadPage // Declare the loadPage variable

async function handleLogin(e) {
  e.preventDefault()
  const email = document.getElementById("login-email").value
  const password = document.getElementById("login-password").value
  const errorDiv = document.getElementById("login-error")

  try {
    errorDiv.textContent = ""
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (error) throw error

    currentUser = data.user
    await loadUserRole()
    showDashboard()
  } catch (error) {
    errorDiv.textContent = error.message
    console.error("[v0] Login error:", error)
  }
}

async function handleSignup(e) {
  e.preventDefault()
  const name = document.getElementById("signup-name").value
  const email = document.getElementById("signup-email").value
  const password = document.getElementById("signup-password").value
  const errorDiv = document.getElementById("signup-error")

  try {
    errorDiv.textContent = ""
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { full_name: name },
        emailRedirectTo: window.location.origin,
      },
    })

    if (error) throw error

    // Create user record in users table
    const { error: insertError } = await supabase.from("users").insert({
      id: data.user.id,
      email,
      full_name: name,
      role: "user",
    })

    if (insertError) throw insertError

    errorDiv.textContent = "Account created! Please check your email to confirm."
    errorDiv.style.color = "green"
  } catch (error) {
    errorDiv.textContent = error.message
    console.error("[v0] Signup error:", error)
  }
}

async function handleLogout() {
  const { error } = await supabase.auth.signOut()
  if (error) {
    console.error("[v0] Logout error:", error)
  }
  currentUser = null
  userRole = null
  showAuthForms()
}

async function loadUserRole() {
  try {
    const { data, error } = await supabase.from("users").select("role").eq("id", currentUser.id).single()

    if (error) {
      console.error("[v0] Error loading user role:", error)
      userRole = "user"
    } else {
      userRole = data.role
    }
  } catch (error) {
    console.error("[v0] Error loading user role:", error)
    userRole = "user"
  }
}

function toggleAuthForm() {
  const loginForm = document.getElementById("login-form")
  const signupForm = document.getElementById("signup-form")
  loginForm.classList.toggle("hidden")
  signupForm.classList.toggle("hidden")
}

function showAuthForms() {
  document.getElementById("auth-container").classList.remove("hidden")
  document.getElementById("dashboard-container").classList.add("hidden")
  document.getElementById("login-form").classList.remove("hidden")
  document.getElementById("signup-form").classList.add("hidden")
}

function showDashboard() {
  document.getElementById("auth-container").classList.add("hidden")
  document.getElementById("dashboard-container").classList.remove("hidden")

  // Update user info
  document.getElementById("current-user").textContent = currentUser.email
  const roleBadge = document.getElementById("user-role")
  roleBadge.textContent = userRole.toUpperCase()
  roleBadge.style.backgroundColor = userRole === "admin" ? "#dc2626" : "#2563eb"

  // Show/hide admin-only navigation
  const adminItems = document.querySelectorAll(".admin-only")
  adminItems.forEach((item) => {
    if (userRole === "admin") {
      item.classList.remove("hidden")
    } else {
      item.classList.add("hidden")
    }
  })

  loadPage("dashboard")
}

// Event Listeners
document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("login-form").addEventListener("submit", handleLogin)
  document.getElementById("signup-form").addEventListener("submit", handleSignup)
  document.getElementById("logout-btn").addEventListener("click", handleLogout)
  checkAuthStatus()
})

// Check auth status on page load
async function checkAuthStatus() {
  try {
    const { data, error } = await supabase.auth.getSession()
    if (data.session) {
      currentUser = data.session.user
      await loadUserRole()
      showDashboard()
    }
  } catch (error) {
    console.error("[v0] Error checking auth status:", error)
  }
}

console.log("[v0] Auth module loaded")
