// Transactions Module
// Declare the supabase variable here or import it
const supabase = {} // Placeholder for the actual supabase variable or import statement

// Search Available Books
async function searchAvailableBooks() {
  const title = document.getElementById("search-by-title").value.toLowerCase()
  const author = document.getElementById("search-by-author").value.toLowerCase()
  const errorDiv = document.getElementById("search-error")
  errorDiv.textContent = ""

  if (!title && !author) {
    errorDiv.textContent = "Please enter either title or author"
    return
  }

  try {
    let query = supabase.from("books").select("*")

    if (title) {
      query = query.ilike("title", `%${title}%`)
    }
    if (author) {
      query = query.ilike("author", `%${author}%`)
    }

    const { data, error } = await query.gt("available_copies", 0)

    if (error) throw error

    const table = document.getElementById("available-books-table")
    const tbody = document.getElementById("available-books-tbody")
    tbody.innerHTML = ""

    if (data.length === 0) {
      errorDiv.textContent = "No available books found"
      table.classList.add("hidden")
      return
    }

    table.classList.remove("hidden")
    data.forEach((book, index) => {
      const row = tbody.insertRow()
      row.innerHTML = `
        <td>${book.title}</td>
        <td>${book.author}</td>
        <td>${book.category}</td>
        <td>${book.available_copies}/${book.total_copies}</td>
        <td><input type="radio" name="selected-book" value="${index}" onchange="selectAvailableBook('${book.id}', '${book.title}', '${book.author}')"></td>
      `
    })
  } catch (error) {
    errorDiv.textContent = error.message
    console.error("[v0] Error searching books:", error)
  }
}

function selectAvailableBook(bookId, title, author) {
  document.getElementById("issue-book-title").value = title
  document.getElementById("issue-book-author").value = author
  const today = new Date().toISOString().split("T")[0]
  document.getElementById("issue-date").value = today

  const returnDate = new Date()
  returnDate.setDate(returnDate.getDate() + 15)
  document.getElementById("return-date").value = returnDate.toISOString().split("T")[0]
}

// Issue Book
document.addEventListener("DOMContentLoaded", () => {
  const issueBookForm = document.getElementById("issue-book-form")
  if (issueBookForm) {
    issueBookForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("issue-error")
      errorDiv.textContent = ""

      try {
        const memberId = Number.parseInt(document.getElementById("issue-member-id").value)
        const bookTitle = document.getElementById("issue-book-title").value
        const authorName = document.getElementById("issue-book-author").value
        const issueDate = document.getElementById("issue-date").value
        const returnDate = document.getElementById("return-date").value
        const remarks = document.getElementById("issue-remarks").value

        if (!memberId || !bookTitle || !authorName || !issueDate || !returnDate) {
          errorDiv.textContent = "All required fields must be filled"
          return
        }

        const today = new Date()
        if (new Date(issueDate) < today) {
          errorDiv.textContent = "Issue date cannot be in the past"
          return
        }

        const issueDateObj = new Date(issueDate)
        const returnDateObj = new Date(returnDate)
        const daysDiff = Math.ceil((returnDateObj - issueDateObj) / (1000 * 60 * 60 * 24))

        if (daysDiff > 15) {
          errorDiv.textContent = "Return date cannot be more than 15 days from issue date"
          return
        }

        // Find book
        const { data: books, error: bookError } = await supabase
          .from("books")
          .select("*")
          .ilike("title", `%${bookTitle}%`)
          .single()

        if (bookError || !books) {
          errorDiv.textContent = "Book not found"
          return
        }

        // Get available serial number
        const { data: serial, error: serialError } = await supabase
          .from("book_serials")
          .select("*")
          .eq("book_id", books.id)
          .eq("status", "available")
          .limit(1)
          .single()

        if (serialError || !serial) {
          errorDiv.textContent = "No available copies of this book"
          return
        }

        // Create transaction
        const { error: transError } = await supabase.from("transactions").insert({
          member_id: memberId,
          book_id: books.id,
          serial_number: serial.serial_number,
          issue_date: issueDate,
          return_date: returnDate,
          remarks,
          status: "issued",
        })

        if (transError) throw transError

        // Update book serial status
        await supabase.from("book_serials").update({ status: "issued" }).eq("serial_number", serial.serial_number)

        // Update available copies
        await supabase
          .from("books")
          .update({ available_copies: books.available_copies - 1 })
          .eq("id", books.id)

        alert("Book issued successfully!")
        e.target.reset()
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error issuing book:", error)
      }
    })
  }

  // Return Book
  const returnBookForm = document.getElementById("return-book-form")
  if (returnBookForm) {
    returnBookForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("return-error")
      errorDiv.textContent = ""

      try {
        const memberId = Number.parseInt(document.getElementById("return-member-id").value)
        const bookName = document.getElementById("return-book-name").value
        const serialNumber = document.getElementById("return-serial-number").value
        const returnDate = document.getElementById("return-expected-date").value

        if (!memberId || !bookName || !serialNumber || !returnDate) {
          errorDiv.textContent = "All fields are required"
          return
        }

        const finePaid = document.getElementById("fine-paid-checkbox").checked

        // Find transaction
        const { data: transaction, error: transError } = await supabase
          .from("transactions")
          .select("*")
          .eq("member_id", memberId)
          .eq("serial_number", serialNumber)
          .eq("status", "issued")
          .single()

        if (transError || !transaction) {
          errorDiv.textContent = "No active transaction found"
          return
        }

        // Calculate fine
        const expectedDate = new Date(transaction.return_date)
        const actualDate = new Date(returnDate)
        let fine = 0

        if (actualDate > expectedDate) {
          const dayOverdue = Math.ceil((actualDate - expectedDate) / (1000 * 60 * 60 * 24))
          fine = dayOverdue * 10 // ₹10 per day
        }

        if (fine > 0 && !finePaid) {
          errorDiv.textContent = `Fine of ₹${fine} pending. Please check the "Fine Paid" checkbox to proceed.`
          return
        }

        // Update transaction
        await supabase
          .from("transactions")
          .update({
            actual_return_date: returnDate,
            fine_amount: fine,
            fine_paid: finePaid,
            status: "returned",
          })
          .eq("id", transaction.id)

        // Update book serial
        await supabase.from("book_serials").update({ status: "available" }).eq("serial_number", serialNumber)

        // Update available copies
        const { data: book } = await supabase
          .from("books")
          .select("available_copies")
          .eq("id", transaction.book_id)
          .single()

        await supabase
          .from("books")
          .update({ available_copies: book.available_copies + 1 })
          .eq("id", transaction.book_id)

        alert("Book returned successfully!")
        e.target.reset()
        document.getElementById("fine-info").classList.add("hidden")
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error returning book:", error)
      }
    })
  }
})

console.log("[v0] Transactions module loaded")
