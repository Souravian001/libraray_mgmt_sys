// Main App Logic

let currentPage = "dashboard"
let currentTab = "add-book"
let supabase // Declare the supabase variable

function loadPage(page) {
  console.log("[v0] Loading page:", page)

  // Hide all pages
  document.querySelectorAll(".page").forEach((p) => p.classList.add("hidden"))

  // Show selected page
  const pageElement = document.getElementById(`page-${page}`)
  if (pageElement) {
    pageElement.classList.remove("hidden")
  }

  // Update nav item active state
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
  })
  if (event && event.target) {
    event.target.classList.add("active")
  }

  currentPage = page

  // Load page-specific data
  if (page === "dashboard") {
    loadDashboardStats()
  } else if (page === "reports") {
    loadReports()
  } else if (page === "transactions") {
    switchTab("book-available")
  }
}

function switchTab(tab) {
  console.log("[v0] Switching tab:", tab)

  // Hide all tabs
  document.querySelectorAll(".tab-content").forEach((t) => t.classList.add("hidden"))
  document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"))

  // Show selected tab
  const tabElement = document.getElementById(`tab-${tab}`)
  if (tabElement) {
    tabElement.classList.remove("hidden")
  }

  // Find and activate the clicked button
  const tabBtns = document.querySelectorAll(".tab-btn")
  const activeBtn = Array.from(tabBtns).find((btn) => btn.textContent.toLowerCase().includes(tab.replace("-", " ")))
  if (activeBtn) {
    activeBtn.classList.add("active")
  }

  currentTab = tab
}

async function loadDashboardStats() {
  try {
    if (!supabase) {
      console.log("[v0] Supabase not initialized yet")
      return
    }

    const { count: bookCount, error: booksError } = await supabase
      .from("books")
      .select("*", { count: "exact", head: true })

    const { count: memberCount, error: membersError } = await supabase
      .from("members")
      .select("*", { count: "exact", head: true })

    const { data: transactionsData, error: transError } = await supabase
      .from("transactions")
      .select("*")
      .eq("status", "issued")

    document.getElementById("stat-total-books").textContent = bookCount || 0
    document.getElementById("stat-total-members").textContent = memberCount || 0
    document.getElementById("stat-issued-books").textContent = transactionsData?.length || 0

    // Calculate overdue
    const now = new Date()
    const overdue = transactionsData?.filter((t) => new Date(t.return_date) < now).length || 0
    document.getElementById("stat-overdue-books").textContent = overdue
  } catch (error) {
    console.error("[v0] Error loading dashboard stats:", error)
  }
}

async function loadReports() {
  try {
    if (!supabase) {
      console.log("[v0] Supabase not initialized yet")
      return
    }

    const { count: bookCount } = await supabase.from("books").select("*", { count: "exact", head: true })

    const { count: memberCount } = await supabase.from("members").select("*", { count: "exact", head: true })

    const { data: transactionsData } = await supabase.from("transactions").select("*")

    document.getElementById("report-total-books").textContent = bookCount || 0
    document.getElementById("report-total-members").textContent = memberCount || 0

    const activeCount = transactionsData?.filter((t) => t.status === "issued").length || 0
    document.getElementById("report-active-transactions").textContent = activeCount

    const now = new Date()
    const overdue = transactionsData?.filter((t) => t.status === "issued" && new Date(t.return_date) < now).length || 0
    document.getElementById("report-overdue").textContent = overdue

    // Load transactions table
    const tbody = document.getElementById("transactions-tbody")
    tbody.innerHTML = ""

    for (const transaction of transactionsData || []) {
      const { data: book } = await supabase.from("books").select("*").eq("id", transaction.book_id).single()

      const { data: member } = await supabase.from("members").select("*").eq("id", transaction.member_id).single()

      const row = tbody.insertRow()
      row.innerHTML = `
        <td>${member?.name || "N/A"}</td>
        <td>${book?.title || "N/A"}</td>
        <td>${transaction.issue_date}</td>
        <td>${transaction.return_date}</td>
        <td><span class="status-badge" style="color: ${transaction.status === "issued" ? "#f59e0b" : "#10b981"}">${transaction.status}</span></td>
        <td>₹${(transaction.fine_amount || 0).toFixed(2)}</td>
      `
    }
  } catch (error) {
    console.error("[v0] Error loading reports:", error)
  }
}

console.log("[v0] App initialized")
