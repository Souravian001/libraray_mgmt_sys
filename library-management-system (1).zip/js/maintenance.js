// Maintenance Module

let supabase // Declare supabase variable
let selectedBook // Declare selectedBook variable
let selectedMember // Declare selectedMember variable
const userRole = "admin" // Declare userRole variable for demonstration purposes

document.addEventListener("DOMContentLoaded", () => {
  // Add Book
  const addBookForm = document.getElementById("add-book-form")
  if (addBookForm) {
    addBookForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("add-book-error")
      errorDiv.textContent = ""

      try {
        const isbn = document.getElementById("book-isbn").value
        const title = document.getElementById("book-title").value
        const author = document.getElementById("book-author").value
        const category = document.getElementById("book-category").value
        const copies = Number.parseInt(document.getElementById("book-copies").value)
        const type = document.querySelector('input[name="type"]:checked').value

        if (!isbn || !title || !author || !category || !copies) {
          errorDiv.textContent = "All fields are required"
          return
        }

        const { error } = await supabase.from("books").insert({
          isbn,
          title,
          author,
          category,
          type,
          total_copies: copies,
          available_copies: copies,
        })

        if (error) throw error

        alert("Book added successfully!")
        e.target.reset()
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error adding book:", error)
      }
    })
  }

  // Search Books
  const searchBookInput = document.getElementById("search-book")
  if (searchBookInput) {
    let bookSearchTimeout
    searchBookInput.addEventListener("input", (e) => {
      clearTimeout(bookSearchTimeout)
      const query = e.target.value.toLowerCase()

      if (!query) {
        document.getElementById("book-search-results").innerHTML = ""
        document.getElementById("update-book-fields").classList.add("hidden")
        return
      }

      bookSearchTimeout = setTimeout(async () => {
        try {
          const { data, error } = await supabase
            .from("books")
            .select("*")
            .or(`isbn.ilike.%${query}%,title.ilike.%${query}%`)

          if (error) throw error

          const resultsDiv = document.getElementById("book-search-results")
          resultsDiv.innerHTML = ""
          data.forEach((book) => {
            const item = document.createElement("div")
            item.className = "search-result-item"
            item.textContent = `${book.title} by ${book.author} (ISBN: ${book.isbn})`
            item.onclick = () => selectBookForUpdate(book)
            resultsDiv.appendChild(item)
          })
        } catch (error) {
          console.error("[v0] Error searching books:", error)
        }
      }, 300)
    })
  }

  // Update Book
  const updateBookForm = document.getElementById("update-book-form")
  if (updateBookForm) {
    updateBookForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("update-book-error")
      errorDiv.textContent = ""

      if (!selectedBook) {
        errorDiv.textContent = "Please select a book to update"
        return
      }

      try {
        const title = document.getElementById("update-book-title").value
        const author = document.getElementById("update-book-author").value
        const category = document.getElementById("update-book-category").value
        const copies = Number.parseInt(document.getElementById("update-book-copies").value)
        const type = document.querySelector('input[name="update-type"]:checked').value

        if (!title || !author || !category || !copies) {
          errorDiv.textContent = "All fields are required"
          return
        }

        const { error } = await supabase
          .from("books")
          .update({
            title,
            author,
            category,
            type,
            total_copies: copies,
          })
          .eq("id", selectedBook.id)

        if (error) throw error

        alert("Book updated successfully!")
        selectedBook = null
        updateBookForm.reset()
        document.getElementById("update-book-fields").classList.add("hidden")
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error updating book:", error)
      }
    })
  }

  // Add Member
  const addMemberForm = document.getElementById("add-member-form")
  if (addMemberForm) {
    addMemberForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("add-member-error")
      errorDiv.textContent = ""

      try {
        const name = document.getElementById("member-name").value
        const email = document.getElementById("member-email").value
        const phone = document.getElementById("member-phone").value
        const membershipType = document.querySelector('input[name="membership_type"]:checked').value

        if (!name || !email || !phone) {
          errorDiv.textContent = "All fields are required"
          return
        }

        const startDate = new Date()
        const endDate = new Date()

        if (membershipType === "6_months") {
          endDate.setMonth(endDate.getMonth() + 6)
        } else if (membershipType === "1_year") {
          endDate.setFullYear(endDate.getFullYear() + 1)
        } else if (membershipType === "2_years") {
          endDate.setFullYear(endDate.getFullYear() + 2)
        }

        const { error } = await supabase.from("members").insert({
          name,
          email,
          phone,
          membership_type: membershipType,
          membership_start_date: startDate.toISOString().split("T")[0],
          membership_end_date: endDate.toISOString().split("T")[0],
        })

        if (error) throw error

        alert("Member added successfully!")
        e.target.reset()
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error adding member:", error)
      }
    })
  }

  // Update Member
  const updateMemberForm = document.getElementById("update-member-form")
  if (updateMemberForm) {
    updateMemberForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("update-member-error")
      errorDiv.textContent = ""

      if (!selectedMember) {
        errorDiv.textContent = "Please select a member to update"
        return
      }

      try {
        const phone = document.getElementById("update-member-phone").value
        const action = document.querySelector('input[name="member-action"]:checked').value

        const updateData = { phone }

        if (action === "extend") {
          const newEndDate = new Date(selectedMember.membership_end_date)
          newEndDate.setMonth(newEndDate.getMonth() + 6)
          updateData.membership_end_date = newEndDate.toISOString().split("T")[0]
          updateData.is_active = true
        } else if (action === "cancel") {
          updateData.is_active = false
        }

        const { error } = await supabase.from("members").update(updateData).eq("id", selectedMember.id)

        if (error) throw error

        alert("Member updated successfully!")
        selectedMember = null
        updateMemberForm.reset()
        document.getElementById("member-update-fields").classList.add("hidden")
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error updating member:", error)
      }
    })
  }

  // User Management
  const userMgmtForm = document.getElementById("user-management-form")
  if (userMgmtForm) {
    userMgmtForm.addEventListener("submit", async (e) => {
      e.preventDefault()
      const errorDiv = document.getElementById("user-management-error")
      errorDiv.textContent = ""

      try {
        const userType = document.querySelector('input[name="user-type"]:checked').value
        const name = document.getElementById("user-name").value

        if (!name) {
          errorDiv.textContent = "Name is required"
          return
        }

        if (userRole !== "admin") {
          errorDiv.textContent = "Only admins can manage users"
          return
        }

        alert("User management feature requires authentication setup")
        e.target.reset()
      } catch (error) {
        errorDiv.textContent = error.message
        console.error("[v0] Error in user management:", error)
      }
    })
  }
})

function selectBookForUpdate(book) {
  selectedBook = book
  document.getElementById("book-search-results").innerHTML = ""
  document.getElementById("update-book-fields").classList.remove("hidden")

  document.getElementById("update-book-isbn").value = book.isbn
  document.getElementById("update-book-title").value = book.title
  document.getElementById("update-book-author").value = book.author
  document.getElementById("update-book-category").value = book.category
  document.getElementById("update-book-copies").value = book.total_copies
  document.querySelector(`input[name="update-type"][value="${book.type}"]`).checked = true
}

async function searchMember() {
  const membershipNumber = document.getElementById("member-search").value
  const errorDiv = document.getElementById("update-member-error")
  errorDiv.textContent = ""

  if (!membershipNumber) {
    errorDiv.textContent = "Please enter membership number"
    return
  }

  try {
    const { data, error } = await supabase.from("members").select("*").eq("id", membershipNumber).single()

    if (error) throw error

    selectedMember = data
    document.getElementById("member-update-fields").classList.remove("hidden")
    document.getElementById("update-member-name").value = data.name
    document.getElementById("update-member-email").value = data.email
    document.getElementById("update-member-phone").value = data.phone
  } catch (error) {
    errorDiv.textContent = "Member not found"
    console.error("[v0] Error searching member:", error)
  }
}

console.log("[v0] Maintenance module loaded")
