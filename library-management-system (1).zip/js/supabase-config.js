// Get credentials from environment or localStorage
const SUPABASE_URL =
  window.SUPABASE_URL || localStorage.getItem("supabase_url") || "https://xvbkwcupvwvgblqnrmhb.supabase.co"

const SUPABASE_ANON_KEY =
  window.SUPABASE_ANON_KEY ||
  localStorage.getItem("supabase_key") ||
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh2Ymt3Y3Vwdnd2Z2JscW5ybWhiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzMxNzgwMDAsImV4cCI6MTkwNDk0NDAwMH0.F0qX4U0V3K8T8w0N0X0V3K8T8w0N0X0V3K8T8w0N0X0"

let supabase = null

// Wait for Supabase library to load, then initialize client
function initSupabase() {
  if (window.supabase && window.supabase.createClient) {
    supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
    console.log("[v0] Supabase initialized successfully")
    return supabase
  } else {
    console.error("[v0] Supabase library not loaded yet, retrying...")
    setTimeout(initSupabase, 100)
  }
}

// Initialize when DOM is ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initSupabase)
} else {
  initSupabase()
}

// Allow manual credential setup for development
window.setSupabaseCredentials = (url, key) => {
  localStorage.setItem("supabase_url", url)
  localStorage.setItem("supabase_key", key)
  location.reload()
}

console.log("[v0] Supabase config loaded")
