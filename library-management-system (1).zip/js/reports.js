// Reports Module

// Reports are loaded in app.js by the loadReports() function

console.log("[v0] Reports module loaded")
