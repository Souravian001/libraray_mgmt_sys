"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { createClient } from "@/lib/supabase/client"

export function ReportsModule() {
  const [stats, setStats] = useState({
    totalBooks: 0,
    availableBooks: 0,
    totalMembers: 0,
    activeMembers: 0,
    issuedBooks: 0,
    overdueBooks: 0,
  })

  useEffect(() => {
    const fetchStats = async () => {
      const supabase = createClient()

      // Fetch statistics
      const [booksData, membersData, issuesData] = await Promise.all([
        supabase.from("books").select("id, available_copies", { count: "exact" }),
        supabase.from("members").select("id", { count: "exact" }).eq("status", "active"),
        supabase.from("book_issues").select("id, status, due_date", { count: "exact" }).eq("status", "issued"),
      ])

      setStats({
        totalBooks: booksData.count || 0,
        availableBooks: 0,
        totalMembers: membersData.count || 0,
        activeMembers: membersData.count || 0,
        issuedBooks: issuesData.count || 0,
        overdueBooks: issuesData.data?.filter((i) => new Date(i.due_date) < new Date()).length || 0,
      })
    }

    fetchStats()
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Total Books</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.totalBooks}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Active Members</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.activeMembers}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Issued Books</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{stats.issuedBooks}</div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm font-medium">Overdue Books</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-destructive">{stats.overdueBooks}</div>
        </CardContent>
      </Card>
    </div>
  )
}
