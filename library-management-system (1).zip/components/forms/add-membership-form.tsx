"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export function AddMembershipForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    membership_type: "6_months",
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)

  const getMembershipEndDate = (type: string) => {
    const today = new Date()
    let days = 180 // 6 months
    if (type === "1_year") days = 365
    if (type === "2_years") days = 730
    const endDate = new Date(today.getTime() + days * 24 * 60 * 60 * 1000)
    return endDate.toISOString().split("T")[0]
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess(false)
    setLoading(true)

    if (!formData.name || !formData.email) {
      setError("Please fill in all required fields")
      setLoading(false)
      return
    }

    try {
      const supabase = createClient()
      const membershipNumber = `MEM-${Date.now()}`
      const today = new Date().toISOString().split("T")[0]

      const { error: dbError } = await supabase.from("members").insert([
        {
          membership_number: membershipNumber,
          name: formData.name,
          email: formData.email,
          phone: formData.phone || null,
          membership_type: formData.membership_type,
          membership_start_date: today,
          membership_end_date: getMembershipEndDate(formData.membership_type),
          status: "active",
        },
      ])

      if (dbError) {
        setError(dbError.message)
        setLoading(false)
        return
      }

      setSuccess(true)
      setFormData({ name: "", email: "", phone: "", membership_type: "6_months" })
    } catch (err) {
      setError("An error occurred")
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Member</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="p-3 bg-destructive/20 text-destructive rounded-md">{error}</div>}
          {success && <div className="p-3 bg-green-500/20 text-green-700 rounded-md">Member added successfully!</div>}

          <div className="space-y-2">
            <Label htmlFor="name">Name *</Label>
            <Input
              id="name"
              placeholder="Member name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="email@example.com"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              placeholder="Phone number"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label>Membership Duration</Label>
            <RadioGroup
              value={formData.membership_type}
              onValueChange={(value) => setFormData({ ...formData, membership_type: value })}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="6_months" id="six" />
                <Label htmlFor="six">6 Months</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="1_year" id="one" />
                <Label htmlFor="one">1 Year</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="2_years" id="two" />
                <Label htmlFor="two">2 Years</Label>
              </div>
            </RadioGroup>
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Adding..." : "Add Member"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
