"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export function UpdateMembershipForm() {
  const [loading, setLoading] = useState(false)

  return (
    <Card>
      <CardHeader>
        <CardTitle>Update Membership</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Membership Number *</label>
            <Input placeholder="Enter membership number" />
          </div>
          <Button disabled={loading} className="w-full">
            {loading ? "Updating..." : "Update Membership"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
