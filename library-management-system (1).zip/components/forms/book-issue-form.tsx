"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"

export function BookIssueForm() {
  const [formData, setFormData] = useState({
    book_title: "",
    author_name: "",
    issue_date: new Date().toISOString().split("T")[0],
    return_date: "",
    remarks: "",
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)
  const [selectedBook, setSelectedBook] = useState(null)

  useEffect(() => {
    // Set default return date (15 days from today)
    const today = new Date()
    const returnDate = new Date(today.getTime() + 15 * 24 * 60 * 60 * 1000)
    setFormData((prev) => ({ ...prev, return_date: returnDate.toISOString().split("T")[0] }))
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess(false)
    setLoading(true)

    if (!formData.book_title || !formData.author_name) {
      setError("Please fill in required fields")
      setLoading(false)
      return
    }

    try {
      // Implementation for issuing books
      setSuccess(true)
    } catch (err) {
      setError("An error occurred")
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Issue Book</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="p-3 bg-destructive/20 text-destructive rounded-md">{error}</div>}
          {success && <div className="p-3 bg-green-500/20 text-green-700 rounded-md">Book issued successfully!</div>}

          <div className="space-y-2">
            <Label htmlFor="book">Book Name *</Label>
            <Input
              id="book"
              placeholder="Book title"
              value={formData.book_title}
              onChange={(e) => setFormData({ ...formData, book_title: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="author">Author Name (Auto-populated)</Label>
            <Input id="author" placeholder="Author name" value={formData.author_name} disabled />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="issue-date">Issue Date *</Label>
              <Input id="issue-date" type="date" value={formData.issue_date} disabled />
            </div>

            <div className="space-y-2">
              <Label htmlFor="return-date">Return Date *</Label>
              <Input
                id="return-date"
                type="date"
                value={formData.return_date}
                onChange={(e) => setFormData({ ...formData, return_date: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="remarks">Remarks</Label>
            <Input
              id="remarks"
              placeholder="Any remarks"
              value={formData.remarks}
              onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Issuing..." : "Issue Book"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
