"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function UpdateBookForm() {
  const [books, setBooks] = useState([])
  const [selectedBook, setSelectedBook] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const fetchBooks = async () => {
      const supabase = createClient()
      const { data } = await supabase.from("books").select("*")
      setBooks(data || [])
    }
    fetchBooks()
  }, [])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Update Book</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Select Book</label>
            <select
              className="w-full border rounded-md p-2 mt-2"
              onChange={(e) => setSelectedBook(books.find((b) => b.id === e.target.value))}
            >
              <option value="">Choose a book...</option>
              {books.map((book) => (
                <option key={book.id} value={book.id}>
                  {book.title}
                </option>
              ))}
            </select>
          </div>

          {selectedBook && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">Update the fields below</p>
              <Button disabled={loading} className="w-full">
                {loading ? "Updating..." : "Update Book"}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
