"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"

export function ReturnBookForm() {
  const [formData, setFormData] = useState({
    book_name: "",
    author_name: "",
    serial_no: "",
    issue_date: "",
    return_date: "",
  })
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    if (!formData.book_name || !formData.serial_no) {
      setError("Please fill in required fields")
      setLoading(false)
      return
    }

    // Implementation for returning books
    setLoading(false)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Return Book</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="p-3 bg-destructive/20 text-destructive rounded-md">{error}</div>}

          <div className="space-y-2">
            <Label htmlFor="book">Book Name *</Label>
            <Input
              id="book"
              placeholder="Book name"
              value={formData.book_name}
              onChange={(e) => setFormData({ ...formData, book_name: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="author">Author Name (Auto-populated)</Label>
            <Input id="author" disabled value={formData.author_name} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="serial">Serial No *</Label>
            <Input
              id="serial"
              placeholder="Serial number"
              value={formData.serial_no}
              onChange={(e) => setFormData({ ...formData, serial_no: e.target.value })}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="issue">Issue Date (Auto-populated)</Label>
              <Input id="issue" type="date" disabled value={formData.issue_date} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="return">Return Date</Label>
              <Input
                id="return"
                type="date"
                value={formData.return_date}
                onChange={(e) => setFormData({ ...formData, return_date: e.target.value })}
              />
            </div>
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Processing..." : "Continue to Fine Payment"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
