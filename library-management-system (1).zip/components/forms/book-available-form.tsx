"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export function BookAvailableForm() {
  const [searchType, setSearchType] = useState("title")
  const [searchValue, setSearchValue] = useState("")
  const [results, setResults] = useState([])
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setResults([])
    setLoading(true)

    if (!searchValue) {
      setError("Please select a search option and enter a value")
      setLoading(false)
      return
    }

    try {
      const supabase = createClient()
      const field = searchType === "title" ? "title" : "author_name"

      const { data, error: dbError } = await supabase.from("books").select("*").ilike(field, `%${searchValue}%`)

      if (dbError) {
        setError(dbError.message)
        setLoading(false)
        return
      }

      setResults(data || [])
    } catch (err) {
      setError("An error occurred")
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Search Available Books</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSearch} className="space-y-4">
          {error && <div className="p-3 bg-destructive/20 text-destructive rounded-md">{error}</div>}

          <div className="space-y-2">
            <Label>Search By</Label>
            <RadioGroup value={searchType} onValueChange={setSearchType}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="title" id="title" />
                <Label htmlFor="title">Title</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="author" id="author" />
                <Label htmlFor="author">Author</Label>
              </div>
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="search">Search Value</Label>
            <Input
              id="search"
              placeholder="Enter search term"
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Searching..." : "Search"}
          </Button>
        </form>

        {results.length > 0 && (
          <div className="mt-6 space-y-2">
            <h3 className="font-semibold">Results:</h3>
            <div className="space-y-2">
              {results.map((book) => (
                <div key={book.id} className="p-3 border rounded-md">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium">{book.title}</p>
                      <p className="text-sm text-muted-foreground">{book.author_name}</p>
                      <p className="text-sm">
                        Available: {book.available_copies}/{book.total_copies}
                      </p>
                    </div>
                    <input type="radio" name="book" value={book.id} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
