"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export function AddBookForm() {
  const [formData, setFormData] = useState({
    title: "",
    author_name: "",
    isbn: "",
    book_type: "book",
    category: "",
    total_copies: "1",
    description: "",
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess(false)
    setLoading(true)

    if (!formData.title || !formData.author_name || !formData.total_copies) {
      setError("Please fill in all required fields")
      setLoading(false)
      return
    }

    try {
      const supabase = createClient()
      const { error: dbError } = await supabase.from("books").insert([
        {
          title: formData.title,
          author_name: formData.author_name,
          isbn: formData.isbn || null,
          book_type: formData.book_type,
          category: formData.category || null,
          total_copies: Number.parseInt(formData.total_copies),
          available_copies: Number.parseInt(formData.total_copies),
          description: formData.description || null,
        },
      ])

      if (dbError) {
        setError(dbError.message)
        setLoading(false)
        return
      }

      setSuccess(true)
      setFormData({
        title: "",
        author_name: "",
        isbn: "",
        book_type: "book",
        category: "",
        total_copies: "1",
        description: "",
      })
    } catch (err) {
      setError("An error occurred")
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Add New Book</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && <div className="p-3 bg-destructive/20 text-destructive rounded-md">{error}</div>}
          {success && <div className="p-3 bg-green-500/20 text-green-700 rounded-md">Book added successfully!</div>}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                placeholder="Book title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="author">Author *</Label>
              <Input
                id="author"
                placeholder="Author name"
                value={formData.author_name}
                onChange={(e) => setFormData({ ...formData, author_name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="isbn">ISBN</Label>
              <Input
                id="isbn"
                placeholder="ISBN"
                value={formData.isbn}
                onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="copies">Total Copies *</Label>
              <Input
                id="copies"
                type="number"
                min="1"
                value={formData.total_copies}
                onChange={(e) => setFormData({ ...formData, total_copies: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                placeholder="Category"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Type</Label>
              <RadioGroup
                value={formData.book_type}
                onValueChange={(value) => setFormData({ ...formData, book_type: value })}
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="book" id="book" />
                  <Label htmlFor="book">Book</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="movie" id="movie" />
                  <Label htmlFor="movie">Movie</Label>
                </div>
              </RadioGroup>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Book description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            />
          </div>

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Adding..." : "Add Book"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
