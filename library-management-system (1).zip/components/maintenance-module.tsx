"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AddBookForm } from "./forms/add-book-form"
import { UpdateBookForm } from "./forms/update-book-form"
import { AddMembershipForm } from "./forms/add-membership-form"
import { UpdateMembershipForm } from "./forms/update-membership-form"
import { UserManagementForm } from "./forms/user-management-form"

export function MaintenanceModule() {
  return (
    <Tabs defaultValue="add-book" className="w-full">
      <TabsList className="grid w-full grid-cols-5">
        <TabsTrigger value="add-book">Add Book</TabsTrigger>
        <TabsTrigger value="update-book">Update Book</TabsTrigger>
        <TabsTrigger value="add-membership">Add Member</TabsTrigger>
        <TabsTrigger value="update-membership">Update Member</TabsTrigger>
        <TabsTrigger value="user-management">User Mgmt</TabsTrigger>
      </TabsList>

      <TabsContent value="add-book">
        <AddBookForm />
      </TabsContent>

      <TabsContent value="update-book">
        <UpdateBookForm />
      </TabsContent>

      <TabsContent value="add-membership">
        <AddMembershipForm />
      </TabsContent>

      <TabsContent value="update-membership">
        <UpdateMembershipForm />
      </TabsContent>

      <TabsContent value="user-management">
        <UserManagementForm />
      </TabsContent>
    </Tabs>
  )
}
