"use client"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MaintenanceModule } from "./maintenance-module"
import { TransactionsModule } from "./transactions-module"
import { ReportsModule } from "./reports-module"

export function AdminDashboard() {
  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Admin Dashboard</h1>

        <Tabs defaultValue="maintenance" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
            <TabsTrigger value="transactions">Transactions</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="maintenance">
            <MaintenanceModule />
          </TabsContent>

          <TabsContent value="transactions">
            <TransactionsModule />
          </TabsContent>

          <TabsContent value="reports">
            <ReportsModule />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
