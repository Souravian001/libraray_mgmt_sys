"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookAvailableForm } from "./forms/book-available-form"
import { BookIssueForm } from "./forms/book-issue-form"
import { ReturnBookForm } from "./forms/return-book-form"

export function TransactionsModule() {
  return (
    <Tabs defaultValue="book-available" className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="book-available">Book Available</TabsTrigger>
        <TabsTrigger value="book-issue">Issue Book</TabsTrigger>
        <TabsTrigger value="return-book">Return Book</TabsTrigger>
      </TabsList>

      <TabsContent value="book-available">
        <BookAvailableForm />
      </TabsContent>

      <TabsContent value="book-issue">
        <BookIssueForm />
      </TabsContent>

      <TabsContent value="return-book">
        <ReturnBookForm />
      </TabsContent>
    </Tabs>
  )
}
