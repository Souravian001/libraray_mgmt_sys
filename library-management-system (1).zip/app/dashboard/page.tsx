import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { AdminDashboard } from "@/components/admin-dashboard"
import { UserDashboard } from "@/components/user-dashboard"

export default async function DashboardPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user role from users table
  const { data: userData } = await supabase.from("users").select("role").eq("id", user.id).single()

  const isAdmin = userData?.role === "admin"

  return isAdmin ? <AdminDashboard /> : <UserDashboard />
}
