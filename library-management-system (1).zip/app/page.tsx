import Link from "next/link"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/server"

export default async function Home() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 to-background">
      <nav className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold">Library Management System</h1>
          <div className="flex gap-4">
            {user ? (
              <>
                <Link href="/dashboard">
                  <Button variant="outline">Dashboard</Button>
                </Link>
                <form action="/api/auth/logout" method="post">
                  <Button type="submit" variant="ghost">
                    Logout
                  </Button>
                </form>
              </>
            ) : (
              <>
                <Link href="/auth/login">
                  <Button variant="outline">Sign In</Button>
                </Link>
                <Link href="/auth/signup">
                  <Button>Sign Up</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-20">
        <div className="text-center space-y-6">
          <h2 className="text-5xl font-bold">Welcome to Library Management System</h2>
          <p className="text-xl text-muted-foreground">Manage books, members, and transactions efficiently</p>

          {user ? (
            <Link href="/dashboard">
              <Button size="lg">Go to Dashboard</Button>
            </Link>
          ) : (
            <div className="flex gap-4 justify-center">
              <Link href="/auth/login">
                <Button size="lg">Sign In</Button>
              </Link>
              <Link href="/auth/signup">
                <Button size="lg" variant="outline">
                  Sign Up
                </Button>
              </Link>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-20">
          <div className="p-6 border rounded-lg bg-card">
            <h3 className="font-bold text-lg mb-2">Manage Books</h3>
            <p className="text-muted-foreground">Add, update, and track your book inventory</p>
          </div>
          <div className="p-6 border rounded-lg bg-card">
            <h3 className="font-bold text-lg mb-2">Member Management</h3>
            <p className="text-muted-foreground">Handle memberships and member information</p>
          </div>
          <div className="p-6 border rounded-lg bg-card">
            <h3 className="font-bold text-lg mb-2">Track Transactions</h3>
            <p className="text-muted-foreground">Issue and return books with fine management</p>
          </div>
        </div>
      </main>
    </div>
  )
}
