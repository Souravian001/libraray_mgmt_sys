export type User = {
  id: string
  email: string
  full_name: string | null
  role: "admin" | "user"
  created_at: string
  updated_at: string
}

export type Member = {
  id: string
  membership_number: string
  name: string
  email: string
  phone: string | null
  membership_type: "6_months" | "1_year" | "2_years"
  membership_start_date: string
  membership_end_date: string
  status: "active" | "expired" | "cancelled"
  created_at: string
  updated_at: string
}

export type Book = {
  id: string
  title: string
  author_name: string
  isbn: string | null
  book_type: "book" | "movie"
  category: string | null
  total_copies: number
  available_copies: number
  description: string | null
  created_at: string
  updated_at: string
}

export type BookSerial = {
  id: string
  book_id: string
  serial_number: string
  status: "available" | "issued" | "damaged"
  created_at: string
  updated_at: string
}

export type BookIssue = {
  id: string
  member_id: string
  book_id: string
  book_serial_id: string
  issue_date: string
  due_date: string
  return_date: string | null
  fine_amount: number
  fine_paid: boolean
  remarks: string | null
  status: "issued" | "returned"
  created_at: string
  updated_at: string
}
